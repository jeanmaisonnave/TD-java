package JeanMaisonnave;

import java.io.Serializable;

import static java.lang.System.currentTimeMillis;

public class Tamagochi extends Thread implements Serializable {
    private String lieu;
    private String satitete;
    private String emotion;
    private String sante;
    private String dernierRepas;
    private String dernierMecontement;
    private int age;
    private long creationTime;

    public Tamagochi() {
        lieu = "table";
        satitete = "repus";
        emotion = "content";
        sante = "vivant";
        dernierMecontement = "";
        dernierRepas ="";
        age = 0;
        creationTime = currentTimeMillis();
    }


    public void run(){
        while(true){
            if (currentTimeMillis() == creationTime + 30000){
                satitete = "faim";
                notifyAll();
            }
            if(satitete == "faim" && System.currentTimeMillis() >= creationTime + 120000){
                sante = "mort";
                notifyAll();
            }
        }
    }


    public String getLieu() {
        return lieu;
    }

    public void setLieu(String lieu) {
        this.lieu = lieu;
    }
}
