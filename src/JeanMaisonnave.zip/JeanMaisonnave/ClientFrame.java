package JeanMaisonnave;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.*;

@SuppressWarnings("serial")
public class ClientFrame extends JFrame {

	private JLabel age;
	private JTextArea logs;
	private JScrollPane scrolledLogs;
	private JButton aTable;
	private JButton salleDeJeu;
	private BufferedWriter w;
	private BufferedWriter writer;
	PrintWriter out = null;
	DataInputStream dataInput = null;


	private Socket socket;

	public ClientFrame(Socket socket) {

		initFrame();
		this.socket = socket;
		try {
			out = new PrintWriter(socket.getOutputStream(), true);
			dataInput = new DataInputStream(socket.getInputStream());
			out.println("creer");
			updateLogs("Tamagochi créé");
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	private void initFrame() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridBagLayout());
		setTitle("Tamagochi");
		setSize(400, 400);

		GridBagConstraints c = new GridBagConstraints();
		age = new JLabel("Age: 25 secondes");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 2;
		c.gridx = 0;
		c.gridy = 0;
		c.weighty = 1;
		add(age, c);

		logs = new JTextArea(15,10);
		logs.setText("Logs:");
		scrolledLogs = new JScrollPane(logs);
		scrolledLogs.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrolledLogs.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		c.gridwidth = 2;
		c.gridx = 0;
		c.gridy = 1;
		c.weighty = 10;
		add(scrolledLogs, c);

		aTable = new JButton("A table!");
		aTable.addActionListener(e -> {
			try {
				out = new PrintWriter(socket.getOutputStream(), true);
				dataInput = new DataInputStream(socket.getInputStream());
				out.println("table");
				updateLogs("A table !");
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		});
		c.gridwidth = 1;
		c.gridx = 0;
		c.gridy = 2;
		c.weighty = 1;
		add(aTable, c);

		salleDeJeu = new JButton("Salle de jeu!");
		salleDeJeu.addActionListener(e -> {
			try {
				out = new PrintWriter(socket.getOutputStream(), true);
				dataInput = new DataInputStream(socket.getInputStream());
				out.println("salle de jeu");
				updateLogs("Salle de jeu!");
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		});
		c.gridwidth = 1;
		c.gridx = 1;
		c.gridy = 2;
		add(salleDeJeu, c);
		setVisible(true);
	}

	private void updateLogs(String content) {
		String temp = logs.getText()+"\n"+content;
		logs.setText(temp);
	}

	public static void main(String[] args) {
		
		try {
			Socket socket = new Socket("localhost",5555);
			ClientFrame frame = new ClientFrame(socket);
			frame.setVisible(true);
			
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
