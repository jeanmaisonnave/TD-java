package JeanMaisonnave;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Serveur {
    private Tamagochi tamagochi;

    public void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(4444);
            try {
                Socket clientSocket = serverSocket.accept();

                DataInputStream dataInput = new DataInputStream(clientSocket.getInputStream());
                DataOutputStream dataOut = new DataOutputStream(clientSocket.getOutputStream());

                BufferedReader br = new BufferedReader(new InputStreamReader(dataInput));
                System.out.println("serveur...");

                while(true){
                    String message = br.readLine();
                    switch (message){
                        case "creer":
                            //on crée le tamagochi
                            tamagochi = new Tamagochi();
                            tamagochi.run();
                            dataOut.writeUTF("Tamagochi created");
                            System.out.println("Tamagochi est créé");
                            break;
                        case "etat":
                            //on renvoie l'état du tamagochi
                            dataOut.writeUTF("lieu:" + tamagochi.getLieu() + " satitete:");
                            break;
                        case "table":
                            //on met le tamagochi à table
                            tamagochi.setLieu("table");
                            System.out.println("Tamagochi est à table");
                            break;
                        case "jeu":
                            //on met le tamgochi dans la salle de jeu
                            tamagochi.setLieu("salle de jeu");
                            System.out.println("Tamagochi est dans la salle de jeu");
                            break;
                    }

                }

                /*clientSocket.close();
                dataOut.close();
                dataInput.close();*/
            } catch (IOException e) {
                System.out.println("Accept failed: 4444");
                System.exit(-1);
            }
        } catch (IOException e) {
            System.out.println("Couldn't not listen on port: 4444");
            System.exit(-1);
        }
    }
}
