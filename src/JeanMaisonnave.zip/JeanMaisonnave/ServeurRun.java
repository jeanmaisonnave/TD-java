package JeanMaisonnave;

public class ServeurRun {
    public static void main(String[] args){
        Serveur s = new Serveur();
        String[] tab = {""};
        s.main(tab);
    }
}
